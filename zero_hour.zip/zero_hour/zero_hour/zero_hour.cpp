﻿// zero_hour.cpp 

#include <iostream>
#include <random>
#include <stdlib.h>
#include <chrono>
using namespace std;

enum Tcell :char
{
	zero = '0',
	cros = 'X',
	EMPTY='_'
	};
enum Tprogress
	{
	WON_AI,
	WON_human,
	nichia,
	Proressing
	};
struct Tcoord
{
	size_t y{ 0 };
	size_t x{ 0 };
};
#pragma.pack(push,1)
struct GameStatus
{
	Tcell** field=nullptr; // поле
	const size_t SIZE{ 5 }; // размер поля
	Tprogress progess{ Proressing };  //статус игры
	Tcell human, ai; //кто чем гамает
	size_t turn{ 0 }; //ходы

};
#pragma.pack(pop)
/*int setrandom(int num, int mark)
{
	int mark = rand() % num;
	return mark;
}*/
void __fastcall init_game(GameStatus& game)
{
	game.field = new Tcell * [game.SIZE];
	for (size_t i = 0; i < game.SIZE; i++)
	{
		game.field[i] = new Tcell[game.SIZE];
	}
	for (size_t y = 0; y < game.SIZE; y++)
	{
		for (size_t x = 0; x < game.SIZE; x++)
		{
			game.field[y][x] = EMPTY;
		}
	}
	if (rand() % 2 != 0)
	{
		game.human = cros;
		game.ai = zero;
		game.turn = 0;
	}
	else
	{
		game.human = zero;
		game.ai = cros;
		game.turn = 1;
	}
}
	
void __fastcall draw_game(GameStatus& game)
{
	cout << "    ";
	for (size_t x = 0; x < game.SIZE; x++)
	{
		cout << x+1 <<"  *  ";
	}
	cout << endl;
	for (size_t y = 0; y < game.SIZE; y++)
	{
		cout << y + 1 << " * ";
		for (size_t x = 0; x < game.SIZE; x++)
		{
			cout << game.field[x][y] << "  I  ";
		}
		cout << endl;
	}


}
void __fastcall erase_game(GameStatus &game)
{
	for (size_t i = 0; i < game.SIZE; i++)
	{
		delete[] game.field[i];
	}
	delete[] game.field;
}
void clear()
	{
	system("clr");
	}

Tprogress winner_is(GameStatus& game)
{
	for (size_t y = 0; y < game.SIZE; y++)
	{
		if (game.field[y][0] == game.field[y][4] && game.field[y][0] == game.field[y][3] && game.field[y][0] == game.field[y][2] && game.field[y][0] == game.field[y][1])
		{
			if (game.field[y][0] == game.human)
				return WON_human;
			if (game.field[y][0] == game.ai)
				return WON_AI;
		}
	}
	for (size_t x = 0; x < game.SIZE; x++)
	{
		if (game.field[0][x] == game.field[4][x] && game.field[0][x] == game.field[3][x] && game.field[0][x] == game.field[2][x] && game.field[0][x] == game.field[1][x])
		{
			if (game.field[0][x] == game.human)
				return WON_human;
			if (game.field[0][x] == game.ai)
				return WON_AI;
		}
	}
	if (game.field[0][0] == game.field[1][1] && game.field[0][0] == game.field[2][2] && game.field[0][0] == game.field[3][3] && game.field[0][0] == game.field[4][4])
	{
		if (game.field[1][1] == game.human)
			return WON_human;
		if (game.field[1][1] == game.ai)
			return WON_AI;
	}
	if (game.field[0][4] == game.field[1][3] && game.field[0][4] == game.field[2][2] && game.field[0][4] == game.field[3][1] && game.field[0][4] == game.field[4][0])
	{
		if (game.field[1][1] == game.human)
			return WON_human;
		if (game.field[1][1] == game.ai)
			return WON_AI;
	}
	bool draw = true;
	for (size_t y = 0; y < game.SIZE; y++)
	{
		for (size_t x = 0; x < game.SIZE; x++)
		{
			if (game.field[y][x] == EMPTY)
			{
				draw = false;
				break;
			}
		}
		if (!draw)
			break;

	}
	if (draw)
		return nichia;


	return Proressing;
}

Tcoord HumanShot(GameStatus& game)
	{
	Tcoord n;
	do
	{
		cout << "ENTER X(1...5)";
		cin >> n.x;
		cout << "ENTER Y(1...5)";
		cin >> n.y;
		n.x--;
		n.y--;

	} while (n.x > 4 || n.y > 4 || game.field[n.x][n.y] != EMPTY);
	return n;

	}
Tcoord AiShot(GameStatus& game)
	{
	if (game.field[2][2] == EMPTY)
	{
		return { 2,2 };
	}
	Tcoord buf[4];
	size_t num = 0;
	if (game.field[0][0] == EMPTY)
	{
		buf[num] = { 0,0 };
		num++;
	}
	if (game.field[0][4] == EMPTY)
	{
		buf[num] = { 0,4 };
		num++;
	}
	if (game.field[4][0] == EMPTY)
	{
		buf[num] = { 4,0 };
		num++;
	}
	if (game.field[4][4] == EMPTY)
	{
		buf[num] = { 4,4 };
		num++;
	}
	if (num > 0)
	{
		const size_t index = rand() % num;
		return buf[index];
	}


	if (game.field[0][1] == EMPTY)
	{
		buf[num] = { 0,1 };
		num++;
	}
	if (game.field[0][2] == EMPTY)
	{
		buf[num] = { 0,2 };
		num++;
	}
	if (game.field[0][3] == EMPTY)
	{
		buf[num] = { 0,3 };
		num++;
	}
	if (game.field[1][0] == EMPTY)
	{
		buf[num] = { 1,0 };
		num++;
	}
	if (game.field[2][0] == EMPTY)
	{
		buf[num] = { 2,0 };
		num++;
	}
	if (game.field[3][0] == EMPTY)
	{
		buf[num] = {3,0};
		num++;
	}
	
	if (num > 0)
	{
		const size_t index = rand() % num;
		return buf[index];
	}

}

	void appologies(GameStatus& game)
	{
		if (game.progess == WON_human)
		{
			cout << "WON_HUMAN";

		}
		else if (game.progess == WON_AI)
		{
			cout << "WON_AI";
		}
		else
			cout << "NI4ia";
	}


int main()
{
	GameStatus game;
	system("Cls");
	
	init_game(game);
	draw_game(game);
	do {
		if (game.turn %2 == 0)
		{
			Tcoord n = HumanShot(game);
			game.field[n.x][n.y] = game.human;
		}
		else
		{
			Tcoord n = AiShot(game);
			game.field[n.x][n.y] = game.ai;
		}
	system("Cls");
	draw_game(game);
	game.turn++;
	game.progess = winner_is(game);
		
		} 
	while (game.progess == Proressing);
		appologies(game);
		erase_game(game);
return 0;



}


